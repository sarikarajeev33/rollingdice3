/*
Write a header comment here about the authors and purpose of this file.
*/

//This all all the include files I can image you needing.
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void){
    
    //This time seeds a random number generator. 
    srand(time(0));
    
    //This time generates a random number.
    rand();
    
    //this line generates a num random number.
    rand();
 
    //Returning 0 inidicates success to the OS
    return 0;
}
